const DESIGN_API_ENPOINT = '/designs';

var nameLists = {};
var tablesRender = {};
var designs = [];

var state = {
  currentStep: 1,
  isRenderTable: {},
  json: {
    header: '',
    footer: ''
  },
  columns: [
  ]
};

const TOTAL_STEPS = 4;

$(".editor").summernote({
  minHeight: 150,
});


$("#header").on("summernote.blur", function() {
  onBlurEditor('header');
});

$("#footer").on("summernote.blur", function() {
  onBlurEditor('footer');
});

function onBlurEditor(id) {
  state.json[id] = $('#' + id).summernote('code');
}

$('#btn-next').click(function() {
  if (state.currentStep == TOTAL_STEPS) {
    return;
  }
  $("#step-" + state.currentStep).removeClass('active');

  state.currentStep++;

  if (state.currentStep == 3) {
    updateNameList();
    var tableIds = Object.keys(nameLists);
    tableIds.forEach(function(tableId) {
      if (state.isRenderTable[tableId]) {
        var nameList = nameLists[tableId];
        var renderArea = `
          <div class="render-wrapper">
            <div class="form"></div>
          </div>
        `;

        var renderId = `render-${tableId}`;
        var $renderArea = $(renderArea);
        $renderArea.attr('id', renderId);
        if ($("#step-3 .playground").find('#' + renderId).length) {
          $("#step-3 .playground").find('#' + renderId).replaceWith($renderArea);
        } else {
          $("#step-3 .playground").append($renderArea);
        }
        myFormRender({
          nameList,
          formSelector:  `#render-${tableId} .form`,
          toolbarSelector: `#render-${tableId} .toolbar`
        });
      }
    });

    initToolbar('.toolbar');

  }

  if (state.currentStep == 4) {
    renderFinal();
  }
  //show it
  $("#step-" + state.currentStep).addClass('active');
});

$('#btn-prev').click(function() {
  if (state.currentStep == 1) {
    return;
  }

  if (state.currentStep == 2) {
    state.isNewTable = false;
  }

  $("#step-" + state.currentStep).removeClass('active');

  state.currentStep--;

  //show it
  $("#step-" + state.currentStep).addClass('active');
});

$("#export").click(function() {
  var $content = $("#modal-export .modal-body textarea");
  var $renderArea = $(`#step-${TOTAL_STEPS}`).find("#render-content");
  var html = '';

  $renderArea.find('table').each(function() {
    var $eTable = $(this);
    $eTable.find('th div').remove();
    $eTable.find('th').removeClass('ui-resizable');
    html += $eTable[0].innerHTML;
  });


  html = html.replace(/class=""/g, '');
  $content.val(html);
  $("#modal-export").modal('show');
});

$("#btn-add-table").click(function() {
  var count = $(".table-config-wrapper").length;
  var tableConfig = `
    <div class="table-config-wrapper">
      <div class="row">
        <div class="col-sm-2">
          <div class="">
            <label for="num-cols">Number of columns:</label>
            <input class="form-control" type="number" name="num-cols" value="3">
          </div>
        </div>
        <div class="col-sm-10">
          <form class="form-inline">
            <div class="name-list-wrapper" class="form-group"></div>
          </form>
        </div>
      </div>
    </div>
  `;

  var $tableConfig = $(tableConfig).attr('id', `table-config-${count + 1}`);
  $("#step-2").append($tableConfig);
  $tableConfig.find('input[name=num-cols]').trigger('input');
});

function initToolbar(toolbarSelector) {
  $(toolbarSelector).empty().ListElements();
}

function updateNameList() {

  var newNameLists = {};
  $('.table-config-wrapper').each(function(i, e) {
    var tableId = $(this).attr('id');
    state.isRenderTable[tableId] = false;
    newNameLists[tableId] = [];
    $(this).find('input[name=col-name]').each(function() {
      var name = $(this).val();
      newNameLists[tableId].push(name);
    });

  });

  var tableIds = Object.keys(newNameLists);
  for (var i = 0; i < tableIds.length; i++) {
    var tableId = tableIds[i];
    var newNameList = newNameLists[tableId] || [];
    var nameList = nameLists[tableId] || [];

    if (newNameList.length != nameList.length) {
      state.isRenderTable[tableId] = true;
      nameLists[tableId] = newNameList;
    } else {
      for (var idx = 0; idx < newNameList.length; idx++) {
        if (nameList[idx] !== newNameList[idx]) {
          state.isRenderTable[tableId] = true;
          nameLists[tableId] = newNameList;
          break;
        }
      }
    }
  }

}

function myFormRender(options) {
  let {nameList, formSelector, toolbarSelector} = options;

  function dropHandler($item, $droppable) {
    //TODO edit markup, change classes

    var input = $($item).find('.hidden').clone().removeClass('hidden');
    $(input).appendTo($droppable);
  }

  var n = nameList.length;
  var table = `
    <table class="dropTable table table-bordered">
      <thead>
        <tr>
        ${nameList.reduce(
          (left, right) => `${left}<th>${right}</th>`,''
        )}
        <th class="trans"></th>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
  `;
  var $table = $(table);
  var $obj = $(formSelector);

  $obj.empty().append($table);
  $obj.append(
    `<button class="btn-add-row btn btn-primary"><i class="glyphicon glyphicon-plus"></i> Add Row</button>`
  );

  var tbody = $obj.find('tbody');

  $table.AreaDroppable();
  setTimeout(function() {
    var w = $(formSelector).width();
    var n = nameList.length;
    var thWidth = ~~((w - 42) / n);
    $obj.find('th').each(function(i, e) {
      if (i < n - 1) {
        $(this).css('width', thWidth + 'px');
      }
    })
  },200)

	var exports = {};

	exports.addDroppableRow = function() {
    var $tr = $(`<tr>
      ${nameList.reduce(
        (left, right) => `${left}<td><div class="droppable"></div></td>`,''
      )}
      <td class="trans">
        <button class="btn-remove-row btn btn-danger">
          <i class="glyphicon glyphicon-trash"></i>
        </button>
      </td>
    </tr>`);
		tbody.append($tr);
    $tr.find('div.droppable').droppable({
      classes: {
        "ui-droppable-active": "ui-state-highlight"
      },
      drop: function( event, ui ) {
        dropHandler(ui.draggable, $(this));
      }
    });
	}
	exports.addDataRow = function(values) {
		var data = [];
		for (var i = 0; i < nameList.length; i++) {
			data.push(values[i] || '');
		}
		tbody.append(
			`<tr>
				${data.reduce(
					(left, right) => `${left}<td>${right}</td>`,''
				)}
			</tr>`
		)
	}
	exports.clone = function() {
		tbody.append(tbody.find('tr:last-child').clone());
	}
	exports._ = {
		tbody: tbody,
		nameList: nameList
	}

	exports.addDroppableRow();

  $obj.find('.btn-add-row').click(exports.addDroppableRow);
  $(formSelector).on('click', '.btn-remove-row', function() {
    var $row = $(this).closest('tr');
    $row.remove();
  })
  return exports;
}

function numColCallback(e) {

  var numOfCol = $(e.target).val() - 0;
  var $tableConfig = $(e.target).closest('.table-config-wrapper');

  $tableConfig.find('.name-list-wrapper').html('');
  for(var i = 0; i < numOfCol; i++) {
      $tableConfig.find('.name-list-wrapper').append(
        `<div class="form-group">
          <input name="col-name" class="form-control" value="Title #${i + 1}"></input>
        </div>`
      );
  }
}
numColCallback({target: '#step-2 input[name=num-cols]'});
$('#step-2').on('input', 'input[name=num-cols]', numColCallback);
$('#step-2').on('keyup', 'input[name=num-cols]', numColCallback);

function renderFinal() {
  var $renderArea = $(`#step-${TOTAL_STEPS}`).find("#render-content");
  var $elements = [state.json.header];

  $(".dropTable").each(function() {
    var $table = createTable($(this));
    $elements.push($table);
  });

  $elements.push(state.json.footer);

  $renderArea.empty().append($elements);

  setTimeout(function() {
    $renderArea.find('table th').resizable();
  }, 500);
}

function createTable($table) {
  var $renderArea = $(`#step-${TOTAL_STEPS}`).find("#render-content");
  var rows = [];
  $table.find('tbody tr').each(function() {
    var $tr = $('<tr>');
    var tds = [];
    $(this).find('td').not(':last-child').each(function() {
      var $td = $(this);
      var $newTd = $('<td>');
      $td.find('.widget .render').each(function(i, e) {
        $newTd.append($(e).children().clone().remove());
      })

      // $newTd.find("input.fb-datepicker").removeClass('hasDatepicker').attr('id', '').datepicker();
      tds.push($newTd);
    });

    $tr.append(tds);
    rows.push($tr);
  });


  var $thead = $table.find('thead').clone().remove()
    , $tbody = $('<tbody>').append(rows)
    , $newTable = $('<table>')
      .addClass('table table-bordered');

  $thead.find('th:last-child').remove();
  setTimeout(function() {
    var w = $renderArea.width();
    var n = $thead.find('th').length;
    var thWidth = ~~((w - 42) / n);
    $thead.find('th').each(function(i, e) {
      if (i < n - 1) {
        $(this).css('width', thWidth + 'px');
      }
    });

    $newTable.append([$thead, $tbody]);
  }, 200);

  return $newTable;
}

$('.not-implement').click(function() {
  swal('Sorry', 'This feature has not been implemented yet!', 'info')
})

function loadSelectDropdown() {
  $.get(DESIGN_API_ENPOINT, function(res) {
    designs = res.items;
  })
}

loadSelectDropdown();
