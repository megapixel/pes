<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Design;

class DesignController extends Controller
{
    public function all(Request $request) {
      $designs = Design::select('id', 'name', 'data', 'attribute_id')->get();
      return [
        'code' => '0',
        'items' => $designs
      ];
    }
}
