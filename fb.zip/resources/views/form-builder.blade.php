<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Form Builder</title>
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js" ></script>
    <script type="text/javascript" src="vendor/summernote/summernote.min.js"></script>
    <script type="text/javascript" src="vendor/sweetalert2/sweetalert2.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/jquery-ui.min.css" />
    <link rel="stylesheet" href="vendor/summernote/summernote.css" />
    <link rel="stylesheet" href="vendor/sweetalert2/sweetalert2.min.css">
    <link rel="stylesheet" href="css/fonts.css" />
    <link rel="stylesheet" href="css/custom.css" />
  </head>
  <body>
    <div class="container">
      <h2>Form Builder Demo</h2>
      <div class="step-container">
        <div class="step active" id="step-1">
          <div class="editors">
            <div class="editor-header">
              <label for="header">Header</label>
              <select class="form-control" name="">
                <option value="">Load From Template</option>
              </select>
            </div>
            <div id="header" class="editor"></div>
            <div class="editor-footer">
              <input class="form-control" name="header-template-name" placeholder="Save as template"/>
              <button class="btn btn-primary not-implement">Save</button>
            </div>

            <div class="editor-header">
              <label for="footer">Footer</label>
              <select class="form-control" name="">
                <option value="">Load From Template</option>
              </select>
            </div>
            <div id="footer" class="editor"></div>
            <div class="editor-footer">
              <input class="form-control" name="header-template-name" placeholder="Save as template"/>
              <button class="btn btn-primary not-implement">Save</button>
            </div>
          </div>
        </div>
        <div class="step" id="step-2">
          <button id="btn-add-table" type="button" class="btn btn-primary"><i class="glyphicon glyphicon-plus"></i> Add Table</button>
          <div class="table-config-wrapper" id="table-config-1">
            <div class="row">
              <div class="col-sm-2">
                <div class="">
                  <label for="num-cols">Number of columns:</label>
                  <input class="form-control" type="number" name="num-cols" value="3">
                </div>
              </div>
              <div class="col-sm-10">
                <form class="form-inline">
                  <div class="name-list-wrapper" class="form-group"></div>
                </form>
              </div>
            </div>
          </div>

        </div>
        <div class="step" id="step-3">
          <div class="row">
            <div class="col-xs-12 col-sm-9">
              <div class="playground"></div>
            </div>
            <div class="col-xs-12 col-sm-3">
              <div class="toolbar scroller" data-spy="affix" data-offset-top="205"></div>
            </div>
          </div>


        </div>
        <div class="step" id="step-4">
          <div id="render-content">

          </div>
          <hr>
          <div class="row">
            <div class="col-xs-12">
              <button class="btn btn-info pull-right" id="export">Export</button>
            </div>
          </div>
        </div>
      </div>
      <div class="text-center">
        <button type="button" name="button" class="btn-nav btn btn-success" id="btn-prev">
          <i class="glyphicon glyphicon-backward"></i>
          Prev
        </button>
        <button type="button" name="button" class="btn-nav btn btn-primary" style="margin-left:5px" id="btn-next">
          Next
          <i class="glyphicon glyphicon-forward"></i>
        </button>
      </div>

    </div>

    <div id="modal-export" class="modal fade">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title text-center">Export Result</h4>
          </div>
          <div class="modal-body">
            <textarea name="view-export" rows="25"></textarea>
          </div>
          <div class="modal-footer">
            <button class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>

    <script src="js/components.js" charset="utf-8"></script>
    <script src="js/custom.js" charset="utf-8"></script>
  </body>
</html>
